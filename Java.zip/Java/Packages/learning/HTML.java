package learning;

public class HTML
{
 public void aboutHTML()
 {
  System.out.println("HTML allows building web applications");
  JavaScript js = new JavaScript();
  js.aboutJS();
 }
}