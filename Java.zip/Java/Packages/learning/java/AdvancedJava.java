package learning.java;

public class AdvancedJava
{
 public void aboutAdvancedJava()
 {
   System.out.println("Advanced Java is implementing web and enterprise applications using the Java language");
 }
}