package learning.java;

public class CoreJava
{
 public void aboutCoreJava()
 {
   System.out.println("Core Java is learning the Java language");
 }
}