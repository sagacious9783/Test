package learning;

public class C
{
 public void aboutC()
 {
  System.out.println("C allows learning of most of the programming techniques ");
 }
}