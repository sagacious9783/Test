package learning;

class JavaScript
{
 public void aboutJS()
 {
  System.out.println("JavaScript allows client side (browser) processing in a web application");
 }
}