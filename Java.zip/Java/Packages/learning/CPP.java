package learning;

public class CPP
{
 public void aboutCPP()
 {
  System.out.println("C++ allows learning of the OOP techniques ");
 }
}