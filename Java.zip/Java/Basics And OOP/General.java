
class General
{
 //a preset signature
 public static void main(String args[])//program execution begins here
 {
  int i;//local variable
  for(i =0; i < 10; i++)
  {
   if(i %2 == 0)
    System.out.println("Hello Java");
   else
    System.err.println("Hello Student");
  }
 }//program ends here
}

