import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Squares extends JFrame implements ActionListener
{
    JLabel lbls[][];
    JButton bttnLeft, bttnRight,bttnUp, bttnDown;
    int x, y;

    Squares()
    {
        x = 0;
        y = 0;
        initComponents();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400, 300);
        setVisible(true);
    }

    void initComponents()
    {
        JPanel pnlLabels = new JPanel(new GridLayout(4,4));

        lbls= new JLabel[4][4];
        //all are references, create JLabel objects and init the references
        int i, j;
        for(i =0; i< lbls.length; i++)
        {
            for(j =0; j< lbls[i].length; j++)
            {
                lbls[i][j] = new JLabel();
                lbls[i][j].setOpaque(true);
                lbls[i][j].setBackground(Color.BLUE);
                pnlLabels.add(lbls[i][j]);
            }
        }

        lbls[x][y].setBackground(Color.BLACK);

        JPanel pnlButtons = new JPanel();
        pnlButtons.setLayout(new FlowLayout());

        bttnLeft = new JButton("Left");
        bttnRight = new JButton("Right");
        bttnUp = new JButton("Up");
        bttnDown = new JButton("Down");

        bttnLeft.addActionListener(this);
        bttnRight.addActionListener(this);
        bttnUp.addActionListener(this);
        bttnDown.addActionListener(this);

        pnlButtons.add(bttnLeft);
        pnlButtons.add(bttnRight);
        pnlButtons.add(bttnUp);
        pnlButtons.add(bttnDown);

        setLayout(new BorderLayout());
        add(pnlLabels, BorderLayout.CENTER);
        add(pnlButtons, BorderLayout.SOUTH);

    }//initComponents

    public void actionPerformed(ActionEvent e)
    {
        int p,q;

        p = x;
        q = y;

        Object temp = e.getSource();  	 
        if(temp.equals(bttnLeft))
            y--;
        else if(temp.equals(bttnRight))
            y++;
        else if(temp.equals(bttnUp))
            x--;
        else if(temp.equals(bttnDown))
            x++;

        if(x < 0 )
        {
            x = 0;
            playBeep();
        }
        else if(y < 0)
        {
            y = 0;
            playBeep();
        }
        else if(x > 3)
        {
            x = 3;
            playBeep();
        }
        else if(y > 3)
        {
            y = 3;
            playBeep();
        }
        else
        {
            lbls[p][q].setBackground(Color.BLUE);
            lbls[x][y].setBackground(Color.BLACK);
        }
    }

    void playBeep()
    {
	Toolkit.getDefaultToolkit().beep();
    }

    public static void main(String args[])
    {
	new Squares();
    }
}
