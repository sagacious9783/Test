//Program to implement Flow Layout

import javax.swing.*;
import java.awt.*;

class FLayout extends JFrame
{
 JButton b1,b2,b3,b4,b5,b6;

 FLayout()
 {
  initComponents();
  setTitle("Flow Layout");
  setSize(400, 300);//w,h
  setDefaultCloseOperation(EXIT_ON_CLOSE);
  setVisible(true);  
 }

 void initComponents()
 {
  b1 = new JButton("B1");
  b2 = new JButton("B2");
  b3 = new JButton("B3");
  b4 = new JButton("B4");
  b5 = new JButton("B5");
  b6 = new JButton("B6");

  setLayout(new FlowLayout(FlowLayout.CENTER));
//  setLayout(new FlowLayout(FlowLayout.LEFT));
//  setLayout(new FlowLayout(FlowLayout.RIGHT));

  Dimension d1 = new Dimension(100, 50);//w,h
  Dimension d2 = new Dimension(150, 150);//w,h
 
  b2.setPreferredSize(d1);
  b5.setPreferredSize(d2);

  add(b1);
  add(b2);
  add(b3);
  add(b4);
  add(b5);
  add(b6);


 }

 public static void main(String args[])
 {
   new FLayout();
 }
}