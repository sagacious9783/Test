import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class JComboJCheck extends JFrame implements ItemListener, Runnable
{
 boolean flag;
 Thread t;
 
 JLabel target;
 JComboBox <String> jcb;
 JCheckBox chkSlide;
 ImageIcon ic1, ic2, ic3, ic4;

 JComboJCheck()
 {
  initComponents();
  setTitle("JCombobox Demo");
  setSize(400, 200);
  setDefaultCloseOperation(DISPOSE_ON_CLOSE);
  setVisible(true);
 }

 void initComponents()
 {
  ic1 = new ImageIcon("images/fish.gif");
  ic2 = new ImageIcon("images/car.gif");
  ic3 = new ImageIcon("images/cat.gif");
  ic4 = new ImageIcon("images/moon.gif");

  target = new JLabel("Fish", ic1, JLabel.CENTER);//constructor takes text, icon and alignment as parameter
  

  String arr[] = {"Fish", "Car", "Cat"};
  jcb= new JComboBox<String> (arr);//constructor takes String arr as parameter
  jcb.addItem("Moon");//adding an item to the combo  

  chkSlide = new JCheckBox("Auto Slide");

  //borderless container
  JPanel p1 = new JPanel(new FlowLayout());
  JPanel p2 = new JPanel(new FlowLayout());
   
  p1.add(jcb);
  p1.add(chkSlide);

  p2.add(target);

  setLayout(new BorderLayout());
  add(p1, BorderLayout.NORTH);
  add(p2, BorderLayout.CENTER);

  //event listener for combo box
  jcb.addItemListener(this);
  chkSlide.addItemListener(this);
 }

 //override the 1 interface method
 //it happens to be the event procedure as well
 public void itemStateChanged(ItemEvent e)
 {
  Object temp = e.getSource();
  if(temp.equals(jcb)) 
    fx1();
  else if(temp.equals(chkSlide))
    fx2();
 }//itemStateChanged

 void fx1()
 {
   String s = jcb.getSelectedItem().toString();
   int q = jcb.getSelectedIndex();
   switch(q)
   {
    case 0: //fish
     target.setText(s);
     target.setIcon(ic1);
     break;
    case 1: //car
     target.setText("Car");
     target.setIcon(ic2);
     break;
    case 2: //cat
     target.setText("Cat");
     target.setIcon(ic3);
     break;
    case 3: //moon
     target.setText(s);
     target.setIcon(ic4);
     break;

   }//switch
 }//fx1

 void fx2()
 {
  if(chkSlide.isSelected())//state : CHECKED or UNCHECKED
  {
   flag = true;
   t = new Thread(this);
   t.start();
  }
  else
  {
   flag = false;
  }
 }

 public void run()
 {
  int i = jcb.getSelectedIndex();
  int q = jcb.getItemCount();

  while(flag)
  {
   i = (i +1)%q;
   jcb.setSelectedIndex(i);

   try
   {
     Thread.sleep(1000);
   }
   catch(InterruptedException ex)
   {}
 
  }//while
 }//run
 public static void main(String args[])
 {
  new JComboJCheck();
 }//main
}//JComboJCheck