import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class JComboDemo extends JFrame implements ItemListener
{
 JLabel target;
 JComboBox <String> jcb;
 ImageIcon ic1, ic2, ic3, ic4;

 JComboDemo()
 {
  initComponents();
  setTitle("JCombobox Demo");
  setSize(400, 200);
  setDefaultCloseOperation(DISPOSE_ON_CLOSE);
  setVisible(true);
 }

 void initComponents()
 {
  ic1 = new ImageIcon("images/fish.gif");
  ic2 = new ImageIcon("images/car.gif");
  ic3 = new ImageIcon("images/cat.gif");
  ic4 = new ImageIcon("images/moon.gif");

  target = new JLabel("Fish", ic1, JLabel.CENTER);//constructor takes text, icon and alignment as parameter
  

  String arr[] = {"Fish", "Car", "Cat"};
  jcb= new JComboBox<String> (arr);//constructor takes String arr as parameter
  jcb.addItem("Moon");//adding an item to the combo  

  //borderless container
  JPanel p1 = new JPanel(new FlowLayout());
  JPanel p2 = new JPanel(new FlowLayout());
   
  p1.add(jcb);
  p2.add(target);

  setLayout(new BorderLayout());
  add(p1, BorderLayout.NORTH);
  add(p2, BorderLayout.CENTER);

  //event listener for combo box
  jcb.addItemListener(this);
 }

 //override the 1 interface method
 //it happens to be the event procedure as well
 public void itemStateChanged(ItemEvent e)
 {
   String s = jcb.getSelectedItem().toString();
   int q = jcb.getSelectedIndex();
   switch(q)
   {
    case 0: //fish
     target.setText(s);
     target.setIcon(ic1);
     break;
    case 1: //car
     target.setText("Car");
     target.setIcon(ic2);
     break;
    case 2: //cat
     target.setText("Cat");
     target.setIcon(ic3);
     break;
    case 3: //moon
     target.setText(s);
     target.setIcon(ic4);
     break;

   }//switch
 }//itemStateChanged

 public static void main(String args[])
 {
  new JComboDemo();
 }//main
}//JComboDemo