//Program to implement Border Layout

import javax.swing.*;
import java.awt.*;

class BLayout extends JFrame
{
 JButton b1,b2,b3,b4,b5;

 BLayout()
 {
  initComponents();
  setTitle("Border Layout");
  setSize(400, 300);//w,h
  setDefaultCloseOperation(EXIT_ON_CLOSE);
  setVisible(true);  
 }

 void initComponents()
 {
  b1 = new JButton("East");
  b2 = new JButton("West");
  b3 = new JButton("North");
  b4 = new JButton("South");
  b5 = new JButton("Center");

  setLayout(new BorderLayout());

  add(b1, BorderLayout.EAST);//east
  add(b2, BorderLayout.WEST);//west
  add(b3, BorderLayout.NORTH);//north
  add(b4, BorderLayout.SOUTH);//south
  add(b5, BorderLayout.CENTER);//center

 }

 public static void main(String args[])
 {
   new BLayout();
 }
}