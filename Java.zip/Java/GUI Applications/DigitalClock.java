import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.util.Date;
import java.text.SimpleDateFormat;

class DigitalClock extends JFrame implements ActionListener, Runnable
{
 boolean flag;
 Thread t;

 JLabel lblDT;
 JButton bttnSS;
 
 Date d;
 SimpleDateFormat sdf;

 DigitalClock(String s)
 {
  d = new Date();
  sdf = new SimpleDateFormat("HH:mm:ss @ dd/MM/yyyy");
  
  initComponents();
  setTitle(s);
  setSize(400, 300);//w,h
  setResizable(false);
  setDefaultCloseOperation(EXIT_ON_CLOSE);//jvm exit
  setVisible(true);//render it

 }

 void initComponents()
 {
  //define the components
  lblDT = new JLabel(getDateTime());
  bttnSS = new JButton("Start");

  //few component properties
  Font f = new Font("Arial", Font.BOLD, 26);//name,style,size
  bttnSS.setFont(f);
  bttnSS.setForeground(Color.GREEN);

  lblDT.setFont(f);
  lblDT.setHorizontalAlignment(JLabel.CENTER);
  lblDT.setForeground(Color.BLUE);

  //add the components into the window
  add(lblDT);
  add(bttnSS);

  //size and position them
  setLayout(null);//manual sizing and positioning
 
  lblDT.setBounds(50, 50, 300, 50);//x,y,w,h  
  bttnSS.setBounds(100, 200, 200, 50);//x,y,w,h  

  //enable event handling for the button
  bttnSS.addActionListener(this);    
 } 

 //interface ActionListener method (event procdure)
 public void actionPerformed(ActionEvent e)
 {//callback method
   String txt = bttnSS.getText();
   if(txt.equalsIgnoreCase("start"))
     fx();
   else if(txt.equalsIgnoreCase("stop"))
     fx1();
  
 }

 String getDateTime()
 {
   d.setTime(System.currentTimeMillis());
   return sdf.format(d);
 }

 void fx()
 {//START
  flag = true;
  t = new Thread(this);
  t.start();
  bttnSS.setText("Stop");
  bttnSS.setForeground(Color.RED);
 }

 void fx1()
 {//STOP
  flag = false;

  bttnSS.setText("Start");
  bttnSS.setForeground(Color.GREEN);
 }

 public void run()
 {
  while(flag)
  {
   try
   {
    lblDT.setText(getDateTime());
    Thread.sleep(990);
   }
   catch(Exception ex)
   {}
  }//while
 }//run
 
 public static void main(String args[])
 {
  new DigitalClock("Digital Clock");
  
 }//main
}
