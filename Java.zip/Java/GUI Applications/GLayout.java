//Program to implement Grid Layout

import javax.swing.*;
import java.awt.*;

class GLayout extends JFrame
{
 JButton b1,b2,b3,b4,b5,b6;

 GLayout()
 {
  initComponents();
  setTitle("Grid Layout");
  setSize(400, 300);//w,h
  setDefaultCloseOperation(EXIT_ON_CLOSE);
  setVisible(true);  
 }

 void initComponents()
 {
  b1 = new JButton("B1");
  b2 = new JButton("B2");
  b3 = new JButton("B3");
  b4 = new JButton("B4");
  b5 = new JButton("B5");
  b6 = new JButton("B6");

  //setLayout(new GridLayout(3,2));//r,c
  setLayout(new GridLayout(3,2,20,10));//r,c,hGap,vGap

  add(b1);//row1 col1 
  add(b2);//row1 col2
  add(b3);//row2 col1
  add(b4);//row2 col2
  add(b5);//row3 col1
  add(b6);//row3 col2


 }

 public static void main(String args[])
 {
   new GLayout();
 }
}