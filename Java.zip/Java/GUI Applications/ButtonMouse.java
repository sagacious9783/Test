import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class ButtonMouse extends JFrame implements MouseListener
{
 JButton bttn;
 JLabel lblTitle, lblEI;
 ImageIcon ic1, ic2;

 ButtonMouse()
 {
  initComponents();  
  setSize(400, 300);//w,h
  setTitle("Mouse Event Demo");
  setDefaultCloseOperation(EXIT_ON_CLOSE);
  setVisible(true);  
 }

 void initComponents()
 {
   ic1 = new ImageIcon("./images/img1.jpg");
   ic2 = new ImageIcon("./images/img2.jpg");
   bttn = new JButton(ic1);
   lblTitle = new JLabel("Mouse Event Demo", JLabel.CENTER);
   lblEI = new JLabel("Mouse Not On Button");
   lblEI.setHorizontalAlignment(JLabel.CENTER);

   Dimension d1 = new Dimension(300, 50);//w,h

   lblTitle.setPreferredSize(d1);
   lblEI.setPreferredSize(d1);

   //a borderless container : PANEL
   JPanel pnlBttn = new JPanel(new FlowLayout());
   pnlBttn.add(bttn);
   //pnlBttn.setBackground(Color.RED);

   //add the components into the window
   setLayout(new BorderLayout());
   add(lblTitle, BorderLayout.NORTH);
   add(pnlBttn , BorderLayout.CENTER);
   add(lblEI, BorderLayout.SOUTH);

   //event handling
   bttn.addMouseListener(this);

 }//initComponents

 //event procedures
 public void mousePressed(MouseEvent e)
 {}
 public void mouseReleased(MouseEvent e)
 {}
 public void mouseClicked(MouseEvent e)
 {
  int x,y,b, cnt;
  String s= "";

  x = e.getX();
  y = e.getY();

  b = e.getButton();
  if(b == MouseEvent.BUTTON1)
    s = "LEFT";
  else if(b == MouseEvent.BUTTON2)
    s = "CENTER";
  if(b == MouseEvent.BUTTON3)
    s = "RIGHT";
  
  cnt = e.getClickCount();

  lblEI.setText(s + " clicked, " + cnt +" times @ coordinates : " + x +"," + y);   
 }
 public void mouseEntered(MouseEvent e)
 {
   bttn.setIcon(ic2);
   lblEI.setText("Mouse on the button");
 }
 public void mouseExited(MouseEvent e)
 {
   bttn.setIcon(ic1);
   lblEI.setText("Mouse not on the button");
 }


 public static void main(String args[])
 {
   new ButtonMouse();
 }
}//ButtonMouse
