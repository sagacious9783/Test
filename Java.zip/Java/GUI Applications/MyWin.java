import javax.swing.*;

class MyWin extends JFrame
{
 MyWin(String s)
 {
  setTitle(s);
  setSize(400, 300);//w,h
  //setDefaultCloseOperation(HIDE_ON_CLOSE);//default
  //setDefaultCloseOperation(EXIT_ON_CLOSE);//jvm exit
  setDefaultCloseOperation(DISPOSE_ON_CLOSE);//current window disposes, when all windows dispose the jvm exits
  //setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);//no action on close

  setVisible(true);//render it
  System.out.println(Thread.activeCount());
  
 }
 
 public static void main(String args[])
 {
  new MyWin("Window 1");
  new MyWin("Window 2");

 }//main
}
