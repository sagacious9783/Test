import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class NumberConverter extends JFrame implements ActionListener
{
 JLabel lblDecimal, lblBinary, lblOctal, lblHex;
 JTextField txtDecimal, txtBinary, txtOctal, txtHex;
 JButton bttnConvert; 
 
 NumberConverter()
 {
  initComponents();
  setSize(500, 400); //w,h
  setResizable(false);//resize blocked
  setTitle("NumberConverter");//window title
  setVisible(true);//render it
  setDefaultCloseOperation(DISPOSE_ON_CLOSE);
 }

 void initComponents()
 {
  //define the components
  lblDecimal = new JLabel("Decimal");
  lblBinary = new JLabel("Binary");
  lblOctal = new JLabel("Octal");
  lblHex = new JLabel("Hexadecimal");

  txtDecimal = new JTextField();
  txtBinary = new JTextField();
  txtOctal = new JTextField();
  txtHex = new JTextField();
 
  bttnConvert = new JButton("Convert"); 

  //add the components into the window
  add(lblDecimal);
  add(lblBinary);
  add(lblOctal);
  add(lblHex);

  add(txtDecimal);
  add(txtBinary);
  add(txtOctal);
  add(txtHex);
  
  add(bttnConvert);

  //position and size the components explicitly
  setLayout(null);
  //component.setBounds(x,y,w,h);
  lblDecimal.setBounds(30, 50, 200, 40);   
  txtDecimal.setBounds(250, 50, 200, 40);   

  lblBinary.setBounds(30, 110, 200, 40);   
  txtBinary.setBounds(250, 110, 200, 40);   

  lblOctal.setBounds(30, 170, 200, 40);   
  txtOctal.setBounds(250, 170, 200, 40);   

  lblHex.setBounds(30, 230, 200, 40);   
  txtHex.setBounds(250, 230, 200, 40);   

  bttnConvert.setBounds(30, 300, 150, 40);
 
  //extra properties
  Font f = new Font("Times New Roman" , Font.BOLD, 30);//Font(name, style, size)
  lblDecimal.setFont(f);
  txtDecimal.setFont(f);
  lblBinary.setFont(f);
  txtBinary.setFont(f);
  lblOctal.setFont(f);
  txtOctal.setFont(f);
  lblHex.setFont(f);
  txtHex.setFont(f);
  bttnConvert.setFont(f);

  txtBinary.setEditable(false);
  txtOctal.setEditable(false);
  txtHex.setEditable(false);

  lblDecimal.setForeground(Color.BLUE);
  lblBinary.setForeground(Color.BLUE);
  lblOctal.setForeground(Color.BLUE);
  lblHex.setForeground(Color.BLUE);
  bttnConvert.setForeground(Color.BLUE);

  //register for event notification
  bttnConvert.addActionListener(this);

 }//initComponentes

 //interface method that is invoked by the system on event 
 public void actionPerformed(ActionEvent e)
 {
  try
  {
    String s = txtDecimal.getText();
    s = s.trim();//leading/trailing spaces get removed
    int n = Integer.parseInt(s);
    convertToBinary(n);
    convertToOctal(n);
    convertToHex(n);
  }
  catch(NumberFormatException ex)
  {
    txtBinary.setText("");
    txtOctal.setText("");
    txtHex.setText("");

    //JOptionPane.showMessageDialog(parent, message);
    //JOptionPane.showMessageDialog(this, "Invalid Input");

    //JOptionPane.showMessageDialog(parent, message, title, icon);
    JOptionPane.showMessageDialog(this, "Invalid Input", "NumberConverter", JOptionPane.ERROR_MESSAGE);

  }  
 }

 //logic
 
 void convertToBinary(int n)
 {
  String temp = "";
  while(n > 0)
  {
    temp = n%2 + temp ;
    n = n/2;
  }
  txtBinary.setText(temp);
 }

 void convertToOctal(int n)
 {
  String temp = "";
  while(n > 0)
  {
    temp = n%8 + temp ;
    n = n/8;
  }
  txtOctal.setText(temp);
 }

 void convertToHex(int n)
 {
  String temp = "";
  int x;
  while(n > 0)
  {
    x = n %16;
    if(x <=9)
      temp = x + temp ;
    else if(x == 10)
      temp = 'A' + temp ;
    else if(x == 11)
      temp = 'B' + temp ;
    else if(x == 12)
      temp = 'C' + temp ;
    else if(x == 13)
      temp = 'D' + temp ;
    else if(x == 14)
      temp = 'E' + temp ;
    else if(x == 15)
      temp = 'F' + temp ;
    
    n = n/16;
  }
  txtHex.setText(temp);
 }


 public static void main(String args[])
 {
   new NumberConverter(); 
 }//main
}//NumberConverter
