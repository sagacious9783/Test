import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class CheckDemo extends JFrame implements ItemListener
{
 JCheckBox cbC, cbCpp, cbJava;
 JLabel lblSelections;

 CheckDemo()
 {
   setSize(300, 300);
   setResizable(false);
   setDefaultCloseOperation(EXIT_ON_CLOSE);
   initComponents();
   setVisible(true);
 }

 void initComponents()
 {
   cbC  = new JCheckBox("C");
   cbCpp = new JCheckBox("C++", true);//checked by default
   cbJava = new JCheckBox("Java");
 
   lblSelections = new JLabel("C++");//as cbCpp is checked by default
   lblSelections.setOpaque(true);
   lblSelections.setBackground(Color.YELLOW);
   lblSelections.setForeground(Color.RED);
   lblSelections.setFont(new Font("Arial", Font.PLAIN, 48));

   setLayout(new GridLayout(4,1));

   add(cbC);
   add(cbCpp);
   add(cbJava);
   add(lblSelections);

   cbC.addItemListener(this);
   cbCpp.addItemListener(this);
   cbJava.addItemListener(this);
 }
 
 public void itemStateChanged(ItemEvent e)
 {
   String sel = "";

   if(cbC.isSelected()) //is checked?
     sel = sel + "C ";
   if(cbCpp.isSelected()) //is checked ?
     sel = sel + "C++ ";
   if(cbJava.isSelected()) //is checked ?
     sel = sel + "Java ";

   //System.out.println(sel);

   lblSelections.setText(sel);   
 }

 public static void main(String args[])
 {
   new CheckDemo();
 }
}