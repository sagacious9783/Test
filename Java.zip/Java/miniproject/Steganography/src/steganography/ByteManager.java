package steganography;

public class ByteManager 
{
    String password;//computer
    int pos;//-1
    int len;//8
    
    ByteManager(String s)
    {
        password = s;
        pos = -1;
        len = password.length();
    }
            
    int encryptTheByte(int data)
    {
        pos = (pos + 1) % len;
        return data ^ password.charAt(pos);
    }
    
    int decryptTheByte(int data)
    {
        pos = (pos + 1) % len;
        return data ^ password.charAt(pos);
    }
}
