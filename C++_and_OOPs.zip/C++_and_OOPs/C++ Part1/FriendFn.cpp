//Study of friend functions

#include <iostream>
using namespace std;

class Myclass
{
private:
    int x; //member variable

public:
    int y; //member variable

    Myclass();//default constructor
    Myclass(int q, int w);//parameterized constructor

    void display();

    //declare main as a friend function
    friend int main();
};

Myclass :: Myclass()//default constructor
{
    cout<<"\n Myclass()";
    x = 1;//preset value
    y = 2; //preset value
}


Myclass :: Myclass(int q, int w)//parameterized constructor
{
    cout<<"\n Myclass(int,int)";
    x = q;//parameter value
    y = w; //parameter value
}

void Myclass :: display()
{
    cout<<"\n"<<x<<" "<<y;
}

int main() //doesnt belong to the class
{
    Myclass m;//allowed, as constructors are public
    m.x++;//allowed, as main is friend
    m.y++;//allowed, as y is public member

    m.display(); //allowed, as display is public
    return 0;
}

//friend functions
/*
A friend function is a non member
function that is granted access of
all (private, protected and public)
the members of the class.

*/
