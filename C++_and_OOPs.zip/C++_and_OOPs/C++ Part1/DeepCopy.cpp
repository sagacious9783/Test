/*
Study of Deep Copy Method and Copy Constructor
-----------------------------------------------------------

When a copy of object needs to be created
(as in case of pass by value) then by default
systems memory copy method is applied.

But it being a shallow copy method, is not
good for cloning objects that refer to external
resources.

Inorder to bypass it and imply code defined
deep copy method, a copy constructor must be
defined by the class.

Deep copy is the code implied to duplicate
the external resource refered by the object.

Ideally it allocates a similar kind of resource
and then transfers data from source resource
to target resource.

Copy Constructor
--------------------
Copy Constructor is a special parameterized 
constructor.
It takes only one parameter and that should 
be an object of current class received by reference.
It implies code that is used to duplicate an
object.
If it is defined then systems memory copy
method gets bypassed and its code is executed
for object cloning.
*/

#include <iostream>
using namespace std;

class DeepCopy
{
private: //would be accessible only within the class
    int *data;
    int size;
public: //would be globally accessible
    DeepCopy(int);
    DeepCopy( DeepCopy &ref);
    void scan();
    void display();
    void increment();
    ~DeepCopy();
};

DeepCopy :: DeepCopy(int x =5)
{
    cout<<"\nDeepCopy(int)";
    size = x;
    //dynamic memory allocation
    data = new int[size];
    scan();
}

//copy constructor
DeepCopy  :: DeepCopy( DeepCopy &ref)
{
    //ref refers to the actual parameter
    //this pointer refers to the formal parameter

    cout<<"\n DeepCopy(DeepCopy &ref)";
    size = ref.size;
    //explicit allocation of external resource
    data = new int[size];
    //duplication of the external resource
    int i;
    for(i =0; i< size; i++)
            data[i] = ref.data[i];

}

void DeepCopy :: scan()
{
    int i;
    cout<<"\n Enter "<<size <<" numbers ";
    for(i =0; i< size; i++)
        cin>>data[i];
        //cin>>*(data+i);
}

void DeepCopy :: increment()
{
    int i;
    for(i =0; i< size; i++)
        data[i]++;
        //++*(data+i);
}

void DeepCopy :: display()
{
    int i;
    cout<<"\n "<<data<< "\n";
    for(i =0; i< size; i++)
        cout<<"  "<<data[i];
        //cout<<" "<<*(data+i);
}

DeepCopy :: ~DeepCopy()
{
    cout<<"\n ~DeepCopy()";
    delete data;
}

void test(DeepCopy obj)
{
    obj.display();
    obj.increment();
    obj.display();
}

int main()
{
    DeepCopy dc(4);
    dc.display();
    cout<<"\n---------------";
    test(dc);
    cout<<"\n---------------";
    dc.display();
    return 0;
}


