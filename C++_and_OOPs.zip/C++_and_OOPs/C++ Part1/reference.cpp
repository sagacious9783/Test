//Study of references
//refer : reference.txt
//see : reference.png

#include <iostream>
using namespace std;

void fx1(int q)
{
    cout<<"\n q : "<<q <<"  "<<&q;
    q++;
    cout<<"\n q : "<<q <<"  "<<&q;

}

void fx2(int &w)
{
    cout<<"\n w : "<<w <<"  "<<&w;
    w++;
    cout<<"\n w : "<<w <<"  "<<&w;

}


int main()
{
    //stand alone reference
    ostream &vout= cout;
    vout<<"\n REFERENCES \n";

    int x;
    x = 10;
    cout<<"\n x : "<<x <<"  "<<&x;
    fx1(x);
    cout<<"\n x : "<<x <<"  "<<&x;
    fx2(x);
    cout<<"\n x : "<<x <<"  "<<&x;

    //stand alone reference
    int &z = x;
    z++;
    cout<<"\n x : "<<x <<"  "<<&x;


    return 0;
}
