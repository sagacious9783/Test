/*
Study of Shallow Copy Method and issues that arise.


When members of an object refers to 
some external resource and such an 
object is passed by value to a function 
then the formal parameter object is
created as a copy of the actual parameter.

To make it a copy system's memory copy 
method is used.
It is a shallow copy method, causing 
duplication of the object's memory block 
only and not of the external resource.

The external resource gets explioted and
in case it is deallocated then it access by
code ahead may cause dangling pointer problem.

*/

#include <iostream>
using namespace std;

class ShallowCopy
{
private: //would be accessible only within the class
    int *data;
    int size;
public: //would be globally accessible
    ShallowCopy(int);
    void scan();
    void display();
    void increment();
    ~ShallowCopy();
};

ShallowCopy :: ShallowCopy(int x =5)
{
    cout<<"\nShallowCopy(int)";
    size = x;
    //dynamic memory allocation
    data = new int[size];
    scan();
}

void ShallowCopy :: scan()
{
    int i;
    cout<<"\n Enter "<<size <<" numbers ";
    for(i =0; i< size; i++)
        cin>>data[i];
        //cin>>*(data+i);
}

void ShallowCopy :: increment()
{
    int i;
    for(i =0; i< size; i++)
        data[i]++;
        //++*(data+i);
}

void ShallowCopy :: display()
{
    int i;
    cout<<"\n "<<data<< "\n";
    for(i =0; i< size; i++)
        cout<<"  "<<data[i];
        //cout<<" "<<*(data+i);
}

ShallowCopy :: ~ShallowCopy()
{
    cout<<"\n ~ShallowCopy()";
    delete data;
}

void test(ShallowCopy obj)
{
    obj.display();
    obj.increment();
    obj.display();
}

int main()
{
    ShallowCopy sc(4);
    sc.display();
    cout<<"\n---------------";
    test(sc);
    cout<<"\n---------------";
    sc.display(); //problem here
    return 0;
}


