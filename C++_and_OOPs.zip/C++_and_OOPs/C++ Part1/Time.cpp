#include <iostream>

using namespace std;
//Program to demonstrate :
//class, object and this pointer
//refer : ClassObjectThis.txt
//see : ClassObjectThis.png

class Time
{
public://discuss later
//data members
    int h, m, s;

//related operations
    void setTime(int a, int b, int c)
    // void setTime(Time *this, int a, int b, int c)
    {
        int h; //would cause shadowing
        h = a;//local variable gets assigned
        this->h = a;//member variable gets assigned
        m = b;//this->m = b;
        s = c;//this->s = c;
    }

    void displayTime()
    // void displayTime(Time * this)
    {
        cout<<"\n"<<h<<":"<<m<<":"<<s;
    }
};
//Hereafter, Time is a user defined datatype

int main()
{
    Time t;// an object of Time

    //Using object "t" to invoke member functions of class Time
    t.setTime(1,2,3); //setTime(&t, 1,2,3);
    t.displayTime();

    return 0;
}
