#include <iostream>
#include<string.h>

using namespace std;
//Program to demonstrate : Object Creation Process

class Person
{
public: //discuss later
    //data members
    char name[20];
    int age;

    //Constructors
    Person()//default constructor
    {
        cout<<"\n Person()";
        age = 0;//preset data
        strcpy(name, "Baby");//preset data
    }

    Person(char n[], int a) //parameterized constructor
    {
        cout<<"\n Person(char[], int)";
        age = a;//parameter data
        strcpy(name, n); //parameter data
    }

    //member functions
    void display()
    {
        cout<<"\n Name : "<<name;
        cout<<"\n Age : "<<age;
    }
};

//execution
int main()
{
    //Object Creation
    cout<<"\n----------";
    Person p1;
    cout<<"\n----------";
    Person p2("vikas", 10);
    cout<<"\n----------";
    //Use
    p1.display();
    p2.display();
    return 0;
}
