//Study of
//Dynamic Memory Management
//Destructor

#include <iostream>
using namespace std;

class DynamicArray
{
private: //would be accessible only within the class
    int *data;
    int size;
public: //would be globally accessible
    DynamicArray(int);
    void scan();
    void display();
    void increment();
    ~DynamicArray();
};

DynamicArray :: DynamicArray(int x =5)
{
    cout<<"\nDynamicArray(int)";
    size = x;
    //dynamic memory allocation
    data = new int[size];
    scan();
}

void DynamicArray :: scan()
{
    int i;
    cout<<"\n Enter "<<size <<" numbers ";
    for(i =0; i< size; i++)
        cin>>data[i];
        //cin>>*(data+i);
}

void DynamicArray :: increment()
{
    int i;
    for(i =0; i< size; i++)
        data[i]++;
        //++*(data+i);
}

void DynamicArray :: display()
{
    int i;
    cout<<"\n";
    for(i =0; i< size; i++)
        cout<<"  "<<data[i];
        //cout<<" "<<*(data+i);
}

DynamicArray :: ~DynamicArray()
{
    cout<<"\n ~DynamicArray()";
    delete data;
}

void test()
{
    DynamicArray d(4);
    d.display();
    d.increment();
    d.display();
}

int main() //doesnt belong to the class
{
    cout<<"\n---------------";
    test();
    cout<<"\n---------------";
    return 0;
}


//Dynamic Memory Management
/*
Memory Management includes
 * memory allocation
 * use
 * deallocation

Memory can be managed by the
system or by the program.

When program takes charge of
memory management then its code
allocates and deallocates the memory.

For memory allocation it uses the
operator "new".

For memory deallocation it uses
the operator "delete".

Approach
-------------
1) Operator new is used for dynamic
memory allocation.

2) It takes the type and size of the
memory block to be allocated.

3) It allocate a block of memory in
heap segment of RAM.

4) It returns the initial address of
the allocated memory block.

5) Use of dynamically allocated memory
is through a pointer to it.

6) After use it must be deallocated
using the operator "delete".
*/


//Destructor
/*
A destructor is a special member function.
It has the same name as of the class preceeded by a ~.
It has no return type specification.
It is always parameterless and hence cannot be overloaded.
It auto runs as life of the object gets over.
It does the resource clean up.

*/
