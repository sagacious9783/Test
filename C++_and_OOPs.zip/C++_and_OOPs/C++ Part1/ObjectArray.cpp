//Array of Objects
//Scope Resolution Operator
//Constructor Overloading

#include <iostream>
using namespace std;

class Myclass
{
public:// discuss later
    int x, y; //member variables

    Myclass();//default constructor
    Myclass(int q);//parameterized constructor
    Myclass(int q, int w);//parameterized constructor

    void display();
};

Myclass :: Myclass()//default constructor
{
    cout<<"\n Myclass()";
    x = 1;//preset value
    y = 2; //preset value
}

Myclass :: Myclass(int q)//parameterized constructor
{
    cout<<"\n Myclass(int)";
    x = y = q;//parameter value
}

Myclass :: Myclass(int q, int w)//parameterized constructor
{
    cout<<"\n Myclass(int,int)";
    x = q;//parameter value
    y = w; //parameter value
}

//void display that belongs to Myclass
void Myclass :: display()
{
    cout<<"\n"<<x<<" "<<y;
}

int main()
{
    //Myclass arr[3];
    Myclass arr[3] = {Myclass(1), Myclass(), Myclass(11,22) };
    int i;

    for(i =0; i < 3; i++)
     arr[i].display();

    return 0;
}

//Array of Objects
/*
C++ allows creation of arrays of
primary and secondary types.

The syntax for array creation :
  datatype arrayName[arraySize];

Examples :
    int arr[3];
    Student team[11];

For an array of primary type the
elements are equivalent to variables
of that type.

And for an array of secondary type
the elements are equivalent to objects
of that type.

By default for each element of the array
(object) the default constructor would
be invoked.
In order to make the system invoke
constructor of choice, array initializer
must be used.

See the code and the diagram.

*/
//Scope Resolution Operator
/*
As per the specification a class, in
C++, contains declarations of the
data members and functions.

The definitions of the member functions
must go outside the class.

But when a member function is
defined outside the class then it
resembles a non member function.
Hence C++ brings in a new syntax
for the signatures of the member
functions.

returnType className :: functionName(parameters)
{}

The added operator :: is the scope
resolution operator and it signifies
that the function belongs to some
class.

The name of the class signifies the
ownership.
*/

//Constructor Overloading
/*
Constructor overloading is defining
multiple constructors for the class
with unique set of parameters.

Overloading constructors allows object
initialization in multiple ways.

Hence it is implementation of OOP
concept : Polymorphism.
*/
