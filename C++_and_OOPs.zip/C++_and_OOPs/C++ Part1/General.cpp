#include <iostream>
using namespace std;

int main() //program starts here
{
    int i;
    for(i =0 ; i< 10; i++)
    {
        if(i %2 == 0)
            cout<<"\n Hello C++";
        else
            cerr<<"\n Hello Student";
    }//for
}//main