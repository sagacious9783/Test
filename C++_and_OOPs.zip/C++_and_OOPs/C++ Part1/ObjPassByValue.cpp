//Passing Object as parameter to a function
//Example of pass by value for objects.
//Example of systems memory copy method

#include <iostream>
using namespace std;

class Myclass
{
private: //default
    int x, y;
public:
    Myclass();
    Myclass(int,int);
    void increment();
    void display();
    ~Myclass();
};

Myclass:: Myclass()
{
    cout<<"\n Myclass() ";
    x = 10;
    y = 20;
}

Myclass:: Myclass(int a, int b)
{
    cout<<"\n Myclass(int,int) ";
    x = a;
    y = b;
}

void Myclass :: increment()
{
    x++;
    y++;
}

void Myclass :: display()
{
    cout<<"\n "<<x<<"  "<<y;
}

Myclass :: ~Myclass()
{
    cout<<"\n ~Myclass()";
}

void test(Myclass obj)
{
    obj.display();
    obj.increment();
    obj.display();
}

int main()
{
    Myclass m(1,2);
    m.display();
    cout<<"\n ------------------ ";
    test(m);
    cout<<"\n ------------------ ";
    m.display();
    return 0;
}

/*
C++ allows passing object as parameter
to a function.
In such a case the actual and the formal
parameters are objects of the same class.

Known the fact that the formal parameter
is initialized by the actual parameter so
in the above case also formal parameter
is made a copy of the actual parameter.

Concluding that when passed as parameters
to a function, the objects are passed by value.

To make the formal parameter object, 
a copy of the actual parameter object; 
system uses memory copy method (also 
known as bit by bit copy method).
It is a shallow copy method.
If it works fine for a class then it may 
be continued. 
But if it doesnt work for a particularly 
designed object then it (memory copy method) 
must be replaced by code provided by the 
class itself.
Such code (if provided) must be written
in copy constructor.

*/