#include <iostream>

using namespace std;
//Program to demonstrate :
//default values to formal parameters of functions

//read the note below
//refer to the comments

void add(int a, int b=0, int c=0)//3 formal parameters
{
    int res;
    res = a+b+c;
    cout<<"\n Addition : "<<res;
}

int main()
{
    int x, y, z;
    x = 10;
    y = 20;
    z = 30;
    add(x);//1 actual parameter
    add(x,y);//2 actual parameters
    add(x,y,z);//3 actual parameters

    return 0;
}

/*
Ideally the count, type and
sequence of actual and formal
parameters of a function must 
match. 
C++ supports application of 
default values to the formal 
parameters of a function. 
 
By this the function may be 
invoked with less number of 
actual parameters. 
 
For the call in which less actual 
parameters are provided, system 
will use the default values of the 
formal parameters. 
 
One must use default values 
to formal parameters of a 
function in case the default 
value does not affect the 
result when less parameters 
are used while invocation.
 
Rule: 
If a formal parameter is 
applied a default value then 
all the following parameters 
must be applied default values. 
 
 */
