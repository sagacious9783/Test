//Study of Access Specifiers

#include <iostream>
using namespace std;

class Myclass
{
private:
    int x; //member variable

public:
    int y; //member variable

    Myclass();//default constructor
    Myclass(int q, int w);//parameterized constructor

    void display();
};

Myclass :: Myclass()//default constructor
{
    cout<<"\n Myclass()";
    x = 1;//preset value
    y = 2; //preset value
}


Myclass :: Myclass(int q, int w)//parameterized constructor
{
    cout<<"\n Myclass(int,int)";
    x = q;//parameter value
    y = w; //parameter value
}

void Myclass :: display()
{
    cout<<"\n"<<x<<" "<<y;
}

int main() //doesnt belong to the class
{
    Myclass m;//allowed, as constructor is public
    //m.x++;//blocked, as x is private member
    m.y++;//allowed, as y is public member

    m.display(); //allowed, as display is public
    return 0;
}

//Access Specifiers
/*
Access specifiers control the usability
of members of the class.
C++ provides 3 types of access specifiers :
1) private
2) protected
3) public

private
----------
private access specifier allows
the usage of the member of the
class within the current class only.

A private member cannot be
accessed by any other code.

private is the default access specifier
for the class.

protected
------------
protected access specifier allows
the usage of the member of the
class
1) within the current class
2) within the derived classes

A protected member cannot be
accessed by any other code.

public
---------
public access specifier doesnt apply
any limit on the usage of the member
of the class.

A public member can be accessed
1) within the current class
2) within the derived classes
3) any other code.

public is the default access specifier
for the struct.

*/
