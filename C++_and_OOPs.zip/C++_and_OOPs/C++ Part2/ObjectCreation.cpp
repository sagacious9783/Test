//Study of Object Creation Methods

#include <iostream>
using namespace std;

class Myclass
{
    int x, y;
public:
    Myclass();
    Myclass(int,int);
    void display();
    ~Myclass();
};

Myclass :: Myclass()
{
    cout<<"\n Myclass() "<<this;
    x = 10;
    y = 20;
}

Myclass :: Myclass(int q, int w)
{
    cout<<"\n Myclass(int,int) "<<this;
    x = q;
    y = w;
}

void Myclass :: display()
{
    cout<<"\n"<<x<<" "<<y;
}

Myclass :: ~Myclass()
{
    cout<<"\n ~Myclass() "<<this;
}

int main()
{
    Myclass m; //object created by declartion method
    Myclass *p;
    p = new Myclass(1,2);//object created by allocation

    //use
    m.display();
    p->display();

    //destruction
    delete p;

    return 0;
}

/*
C++ allows object creation in 2 ways :
1) Declaration
2) Allocation

Declaration method uses variable style
object creation.
Syntax : dataType objectName;
Example : Myclass m;

Such objects get allocated in STACK segment
of RAM.
They are accessible by name and by their address.
They get a local life as per the scope of declaration.


Allocation method uses operator "new" for
object creation.

Syntax : datatype *p = new datatype();
Example : Myclass *p = new Myclass();

Such objects get allocated in HEAP segment
of RAM.
They are accessible by their address.
They get a customized life as per the code
implementation.
They would deallocate on call to operator 
"delete" or when program ends.

*/
