//Study Inheritance of DATA
//refer : inheritance.txt
//see the diagram

#include <iostream>
using namespace std;

class A
{
protected://to make it accessible to the derived class
    int x, y;
public:
    A();
    A(int,int);
    ~A();
};

A ::A()
{
    cout<<"\n A :: A() ";
    x = 10;
    y = 20;
}

A ::A(int p, int q)
{
    cout<<"\n A :: A(int,int) ";
    x = p;
    y = q;
}

A :: ~A()
{
    cout<<"\n ~A()";
}

//inheritance
class B : public A
{
    int z;
public:
    B();
    B(int,int,int);
    ~B();

    void display();
};

B :: B() : A()
{
    cout<<"\n B ::B() ";
    z = x+ y;
}

B :: B(int p, int q, int r) :A(p,q)
{
    cout<<"\n B ::B(int,int,int) ";
    z = r;
}

B :: ~B()
{
    cout<<"\n ~B()";
}

void B :: display()
{
    cout<<"\n x : "<<x;
    cout<<"\n y : "<<y;
    cout<<"\n z : "<<z;
}

int main()
{
    B objB(1,2,3);//inheritance of data

    objB.display();//extended code
    return 0;
}
