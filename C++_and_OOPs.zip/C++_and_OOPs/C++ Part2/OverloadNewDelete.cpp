//Study of Operator Overloading
#include <iostream>
#include<stdlib.h>

using namespace std;

class Myclass
{
    int x, y;
public:
    Myclass();
    Myclass(int,int);
    void display();
    ~Myclass();

    //overload operators new and delete
    void *  operator new(size_t s);
    void operator delete(void *p);
};

Myclass :: Myclass()
{
    cout<<"\n Myclass() "<<this;
    x = 10;
    y = 20;
}

Myclass :: Myclass(int q, int w)
{
    cout<<"\n Myclass(int,int) "<<this;
    x = q;
    y = w;
}

void Myclass :: display()
{
    cout<<"\n"<<x<<" "<<y;
}

Myclass :: ~Myclass()
{
    cout<<"\n ~Myclass() "<<this;
}

void * Myclass :: operator new(size_t s)
{
    cout<<"\n In new to allocate "<<s<<" bytes";
    void *p = malloc(s);
    cout<<"\n allocated object at address : "<<p;
    return p;
}

void Myclass :: operator delete(void *p)
{
    cout<<"\n In delete to deallocate the object at address : "<<p;
    free(p);
}

int main()
{
    Myclass *p;
    p = new Myclass(1,2);//object created by allocation

    //use
    p->display();

    //destruction
    delete p;

    return 0;
}

/*
Known that operator new and operator delete 
are designed to work on objects of primary and
secondary types.

Still for customized memory management C++
allows overloading the two.

In case a program overloads the operator new 
and operator delete then it is mandatory to use 
the following specified signatures.

void * operator new(size_t) {}
void operator delete(void *p) {}

*/
