//Study of Operator Overloading
#include <iostream>
using namespace std;

class Time
{
    int h,m,s;
public:
    Time();
    Time(int,int,int);
    void display();

    Time operator +( Time &);
    Time operator -( Time &);
    int operator ==( Time &);
    Time operator +( int );
    Time& operator = (int );
    Time operator ++(int a);//postfix
    Time&  operator ++();//prefix
    int operator []( int);
    Time& operator =(Time &);
    Time *  operator ->();
    void operator ()(int , int , int);
    void operator ()(Time &);


    //type conversion
    operator int();
    operator double();

    //non member functions to implement operator action
    friend Time operator + (int , Time &);
    friend istream & operator >>(istream &in, Time &r);
    friend ostream & operator <<(ostream &out, Time &r);

};

Time :: Time()
{
    h = m = s = 0;
}

Time :: Time(int a, int b, int c)
{
    h = a;
    m = b;
    s = c;
}

void Time :: display()
{
    cout<<"\n"<<h<<":"<<m<<":"<<s;
}

Time Time :: operator -(Time &r)
{
    Time temp;
    temp.h = h - r.h;
    temp.m = m - r.m;
    temp.s = s - r.s;
    return temp;
}

Time Time :: operator +( Time &r)
{
    Time temp;
    temp.h = h + r.h;
    temp.m = m + r.m;
    temp.s = s + r.s;
    return temp;
}

int Time :: operator ==(Time &r)
{
    if(h == r.h && m == r.m && s == r.s)
        return 1;//true
    return 0;//false
}

Time Time :: operator +( int x)
{
    Time temp;
    temp.h = h + x;
    temp.m = m + x;
    temp.s = s + x;
    return temp;
}

Time operator + (int x, Time &r)
{
    Time temp;
    temp.h = x + r.h;
    temp.m = x+ r.m;
    temp.s = x + r.s;
    return temp;
}

Time& Time :: operator = (int x)
{
    cout<<"\n this : "<<this;
    h = m = s = x;
    return *this;//return caller object for the sake of cascading support
}

Time :: operator int()
{
    cout<<"\n this : "<<this;
    int ans;
    ans = h*60*60 + m*60 + s;
    return ans;
}

Time :: operator double()
{
    double ans;
    ans = h + m/60.0 + s/(60.0*60.0);
    return ans;
}


Time Time :: operator ++(int a)//postfix
{
    a = a;

    //copy of original
    Time temp;
    temp.h = h;
    temp.m = m;
    temp.s = s;

    //increment
    h++;
    m++;
    s++;

    //return original
    return temp;
}

Time& Time :: operator ++()//prefix
{
    //increment
    ++h;
    ++m;
    ++s;

    //return current incremented object
    return *this;
}

int Time :: operator []( int x)
{
    if(x == 0)
        return h;
    else if(x == 1)
        return m;
    else
        return s;
}

Time& Time :: operator =(Time &r)
{
    cout<<"\n &r "<<&r;
    h = r.h;
    m = r.m;
    s = r.s;
    return *this;
}

ostream & operator <<(ostream &out, Time &r)
{
    out<<"\n"<<r.h<<":"<<r.m<<":"<<r.s;
    return out;
}

istream & operator >>(istream &in, Time &r)
{
    cout<<"\n Enter hours ";
    in>>r.h;
    cout<<"\n Enter minutes ";
    in>>r.m;
    cout<<"\n Enter seconds ";
    in>>r.s;
    return in;
}


Time * Time :: operator ->()
{
  //some implementation
  h--;
  m--;
  s--;
  return this; //must return address of object of current class
}

//t1(t2)
void Time :: operator ()(Time &r)
{
 h = r.h;
 m = r.m;
 s = r.s;
}

//t1(1,2,3);
void Time :: operator ()(int a, int b, int c)
{
 h = a;
 m = b;
 s = c;
}

int main()
{
    Time t1(1,2,3);
    Time t2(10,20,30);
    Time t3;
    //cout<<"\n &t1 "<<&t1;
    //cout<<"\n &t2 "<<&t2;
    //cout<<"\n &t3 "<<&t3;

    //cin>>t3;
    //t3->display();

    t1(5,6,7);
    t3(t1);

    //t3 = t1 + t2;
    //t3 = t1 - t2;

    //t3 = t1 + 5;
    //t3 = 5+ t1;

    //t2 = t1 = 5;
    /*
    if(t1 == t2)
        cout<<"\n Objects are equal ";
    else
        cout<<"\n Objects are not equal";
    */
   // int x ;
   // double y;
   // x = t1;
   // y = t1;
   // cout<<"\n x : "<<x;
   // cout<<"\n y : "<<y;

   //t3 = t1++;
   //t3 = ++t1;
/*
   int i;
   for(i =0; i< 3; i++)
   {
       cout<<"\n"<<t1[i];
   }
*/

    cout<<t1<<t2<<t3;
    return 0;
}
/*
System allows application of numerous
operators on variables of primary types.

But for objects of secondary types,
system supports use of following limited
set of operators.

1) = (assignment)
2) sizeof (size calculation)
3) . (member access)
4) & (fetching memory location)
5) operator new and delete
6) * and -> (dereferencing) on pointers of secondary types.

By default the use of other operators
on objects of secondary types is illegal.

If a program defines an operator function
that implements the action of an operator
on objects of secondary types then
the use of the operator gets allowed.

Doing so is termed as Operator Overloading.

Learn By Case Study
--------------------------------------

Case 1:  t1+ t2
Here operator + is applied on two Time objects.
For the statement, system would treat :
t1 as caller object
+ as operator function
t2 as parameter to the function
See the implementation.
--------------------------------------

Case 2:  t1 - t2
Here operator - is applied on two Time objects.
For the statement, system would treat :
t1 as caller object
- as operator function
t2 as parameter to the function
See the implementation.
--------------------------------------

Case 3 : t1 == t2
Here operator == is applied on two Time objects.
For the statement, system would treat :
t1 as caller object
== as operator function
t2 as parameter to the function
See the implementation.
--------------------------------------

Case 4:  t1+ 5
Here operator + is applied on one Time object and one int.
For the statement, system would treat :
t1 as caller object
+ as operator function
5 as parameter to the function
See the implementation.
--------------------------------------

Case 5:  5 + t1
Here operator + is applied on one int and one Time object.
Observe the position on int operand.
It is on the LHS of the operator +.
It means the int tends to be the caller object for the operator function.
It is not possible as data types mismatch.
Hence the operator function needs to be invoked without any caller object.
Hence the operator function needs to be defined as a non member function.
(Recollect that non member function donot require a caller object for invokation.)

When an operator function is overloaded as a non member function then :
The LHS operand is the first parameter.
The RHS operand is the second parameter.
The operator function invokes on itself (without any caller object).
See the implementation.
--------------------------------------

Case 6 : t1 = 5
Known that operator = works for objects of primary and secondary types both.
It does the assignment, but it requires that the two operands must be of same data type.
Here operator = is applied on one Time object and one int.
Such a support is not available by default.
Hence the operator needs to be overloaded.

For the statement, system would treat :
t1 as caller object
= as operator function
5 as parameter to the function
See the implementation.
--------------------------------------------------------

Case 7:  x = t1
Here operator = is applied on one int and one Time object.
Observe the position on x (int operand).
It is on the LHS of the operator +.
It means the int tends to be the caller object for the operator function.
It is not possible as data types mismatch.
Hence the operator function needs to be invoked without any caller object.
Hence the operator function needs to be defined as a non member function.
Recollect that operator = cannot be overloaded as a non member function.

Now what?
The problem cannot be resolved using operator overloading.
But the theory of type conversion may be applied here.

Type conversion is converting objects
of secondary data types into values of
primary data types.

For type conversion, a conversion function
is to be defined as follows :

operator <target_primary_type>()
{
   conversion logic
   return value of target_primary_type
}

See 2 implementations.
--------------------------------------------------

Case 8 : t1++
Case 9 : ++t1

In the above two cases operator ++
is applied in two forms on object of Time.

Theory wise prefix usage increments
the value of operand by 1 and returns
the incremented equivalent.

And the postfix usage increments the
value of the operand by 1 but returns
the original equivalent.

Hence two functions need to be defined.

For the above calls
t1 is the caller object.
++ is the operator function being called.
The operator function is parameterless
because ++ is a unary operator.

By definition it is realized that the
two functions take the same signature.
This would be a compiler level issue.

This issue was identified by the developers of C++
and they came up with following compiler fix.
The definition of postfix ++ must receive an
int as a formal parameter.
But at place of call, the parameter must not be
passed i.e. operator must be used as unary.
System will internally treat it as binary.

By this the two forms take up different signatures
and implementations becomes possible.

See the code.
----------------------------------------------------

case 10 : Using object like an array i.e. t[1]
Here operator [] is applied on one Time object and one int.
For the statement system treats :
t as the caller object
[] as the operator function
1 as the parameter

See the implementation.

FYI : Operator [] can be overloaded as
a member function only.
----------------------------------------------------

case 11 : t1 = t2
Even though assignment operator works for
objects of primary and secondary types
still it can be overloaded for custom requirements.

It can only be overloaded as a member function.

For the statement system treats :
t1 as the caller object
= as the operator function
t2 as the parameter

See the implementation.
----------------------------------------------------

case 12 : cout<<t1
Known that operator << is used to output
the value of primary types.
But it doesnt support outputting objects of
secondary types, hence it is overloaded
for extended support.

Here operator << is applied on one ostream and one Time object.
Observe the position on cout (ostream operand).
It is on the LHS of the operator <<
It means the cout tends to be the caller object for the operator function.
It is not possible as data types mismatch.
Hence the operator function needs to be invoked without any caller object.
Hence the operator function needs to be defined as a non member function.
(Recollect that non member function donot require a caller object for invokation.)

When an operator function is overloaded as a non member function then :
The LHS operand is the first parameter.
The RHS operand is the second parameter.
The operator function invokes on itself (without any caller object).
See the implementation.
--------------------------------------

case 13 : cin>>t1
Known that operator >> is used to input
value of primary types.
But it doesnt support fetching objects of
secondary types, hence it is overloaded
for extended support.

Here operator >> is applied on one istream and one Time object.
Observe the position on cin (istream operand).
It is on the LHS of the operator >>
It means the cin tends to be the caller object for the operator function.
It is not possible as data types mismatch.
Hence the operator function needs to be invoked without any caller object.
Hence the operator function needs to be defined as a non member function.
(Recollect that non member function donot require a caller object for invokation.)

When an operator function is overloaded as a non member function then :
The LHS operand is the first parameter.
The RHS operand is the second parameter.
The operator function invokes on itself (without any caller object).
See the implementation.

--------------------------------------
Case 14 : Operator new and Operator delete

See : OverloadNewDelete.cpp
--------------------------------------
Case 15 : t1->member
Here member access operator (infix dereferencing operator)  -> is applied on 1 Time object and a member of the class.

In this case :
-> is the operator function being called
t1 is its caller object
It takes no parameters, because for overloading it acts as a unary operator.
It must return address of an object of the class.
see the code.
-----------------------------
Case 16 : t1(params)
Here operator () is applied on 1 Time object and on an arbitrary set of parameters.

In this case :
t1 is its caller object
() is the operator function being called
params are any arbitrary set of parameters.

The function can have any arbitrary return type.

Some texts suggest that the parameters to () can take default values also, but modern compilers do not support it.
See 2 examples.

-----------------------------------------
Operator Overloading Restrictions

There are some restrictions that apply
to operator overloading.

* New operators cannot be defined using operator overloading.
* Precedence/Associativity of an operator cannot be altered.
* Number of operands that an operator takes cannot be changed,
  except for the operator().
* Operator functions cannot have default arguments,
  except for the operator().
* These operators cannot be overloaded :-
  . :: .* ?
* There are some restrictions that apply to
  friend operator functions.
  You cannot overload the
  = () [] �> operators
  by using a non member function.

 */

